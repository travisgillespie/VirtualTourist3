//
//  FlickrSearcher.swift
//  flickrSearch
//
//  Created by Richard Turton on 31/07/2014.
//  Copyright (c) 2014 Razeware. All rights reserved.
//

import Foundation
import UIKit
import CoreData

struct FlickrSearchResults {
    let lat : NSNumber
    let lon : NSNumber
}


class Flickr {
    lazy var coreDataStack = CoreDataStack()
    var i = 0
    func searchFlickrForLocationStoreResults(lat: NSNumber, lon: NSNumber, completion : (results: FlickrSearchResults?, error : NSError?) -> Void) {
        
        //change the func name and the parameter
        let searchURL = flickrSearchURLForLocation(lat, lon: lon)
        let searchRequest = NSURLRequest(URL: searchURL)
        let searchSession = NSURLSession.sharedSession()
        
        let task = searchSession.dataTaskWithRequest(searchRequest, completionHandler: {data, response, error in
            if error != nil {
                completion(results: nil,error: error)
                return
            }
            
            do {
//                print("searchFlickrForLocation-> nil \nDATA \(data!)\nRESPONSE \(response!)")

                let resultsDictionary = try NSJSONSerialization.JSONObjectWithData(data!, options: [.AllowFragments, .MutableContainers]) as! NSDictionary
//                print("resultsDictionary-> \(resultsDictionary)")
                
                switch (resultsDictionary["stat"] as! String) {
                case "ok":
                    print("Results processed OK")
                case "fail":
                    let APIError = NSError(domain: "FlickrSearch", code: 0, userInfo: [NSLocalizedFailureReasonErrorKey:resultsDictionary["message"]!])
                    completion(results: nil, error: APIError)
                    return
                default:
                    let APIError = NSError(domain: "FlickrSearch", code: 0, userInfo: [NSLocalizedFailureReasonErrorKey:"Uknown API response"])
                    completion(results: nil, error: APIError)
                    return
                }
                
                
                let photosContainer = resultsDictionary["photos"] as! NSDictionary
                let photosReceived = photosContainer["photo"] as! [NSDictionary]
                
                for flickrPhoto in photosReceived {
                    let photoID = flickrPhoto["id"] as? String ?? ""
                    let farm = flickrPhoto["farm"] as? Int ?? 0
                    let serverID = flickrPhoto["server"] as? String ?? ""
                    let secret = flickrPhoto["secret"] as? String ?? ""
                    let flickrPhoto = self.flickrImageURLAsString(farm, server: serverID, photoID: photoID, secret: secret)

                    let photo = Photo(imageURL: flickrPhoto, context: self.coreDataStack.managedObjectContext)
                    print("\nphoto-> \(++self.i): \(photo)")
                    
                    self.coreDataStack.saveMainContext()
                }

            } catch let JSONError as NSError {
                print("NOPE \(JSONError)")
                completion(results: nil, error: JSONError)
                return
            }
        })
        task.resume()
    }

    func flickrImageURLAsString(farm: Int, server: String, photoID: String, secret: String, size:String = "t") -> String {
        let url = "https://farm\(farm).staticflickr.com/\(server)/\(photoID)_\(secret)_\(size).jpg"
        return url
    }
    
    private func flickrSearchURLForLocation(lat: NSNumber, lon: NSNumber) -> NSURL {
        
        let apiKey = "f4af49a216cf5a63f64dfcebbaa976ba"
        let perPage = 20
        let pageNumber = 1 //convert to RANDOM # b/w 1 - Last Page# In callback or get rid of this parameter in the callback
        let accuracy = 16
        
//        https://www.flickr.com/services/api/explore/flickr.photos.search
        let url = "https://api.flickr.com/services/rest/?method=flickr.photos.search&api_key=\(apiKey)&accuracy=\(accuracy)&lat=\(lat)&lon=\(lon)&per_page=\(perPage)&page=\(pageNumber)&format=json&nojsoncallback=1"
        return NSURL(string: url)!
    }
}