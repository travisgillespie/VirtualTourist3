//
//  FlickrPhotoCell.swift
//  VirtualTourist
//
//  Created by Travis Gillespie on 11/13/15.
//  Copyright © 2015 Travis Gillespie. All rights reserved.
//

import UIKit

class FlickrPhotoCell: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
}