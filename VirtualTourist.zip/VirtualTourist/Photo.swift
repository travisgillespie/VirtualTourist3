//
//  Photo.swift
//  VirtualTourist
//
//  Created by Travis Gillespie on 11/11/15.
//  Copyright © 2015 Travis Gillespie. All rights reserved.
//

import Foundation
import CoreData


class Photo: NSManagedObject {

    struct Keys {
        static let URL = "url"
        static let Title = "title"
        static let File = "file"
    }
    
    /// The file name in the documents directory... I need to research this... don't know how to set this up or what it's for
    @NSManaged var file: String
    
    /// The associated pin
    @NSManaged var pin: Pin?
    
    override init(entity: NSEntityDescription, insertIntoManagedObjectContext context: NSManagedObjectContext?) {
        super.init(entity: entity, insertIntoManagedObjectContext: context)
    }
    
    init(imageURL: String, context: NSManagedObjectContext) {
        let entity = NSEntityDescription.entityForName("Photo", inManagedObjectContext: context)!
        super.init(entity: entity, insertIntoManagedObjectContext: context)
        
        url = NSString(string: imageURL) as String
    }

}