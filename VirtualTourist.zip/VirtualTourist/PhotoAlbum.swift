//
//  PhotoAlbum.swift
//  VirtualTourist
//
//  Created by Travis Gillespie on 11/5/15.
//  Copyright © 2015 Travis Gillespie. All rights reserved.
//

import Foundation
import UIKit
import MapKit
import CoreData

//protocol PinPickerDelegate: class{
//    func didSelectPin(pin: Pin)
//}

// MARK: - Globals
let BASE_URL = "https://api.flickr.com/services/rest/"
let METHOD_NAME = "flickr.photos.search"
let API_KEY = "f4af49a216cf5a63f64dfcebbaa976ba"
let EXTRAS = "url_m"
let SAFE_SEARCH = "1"
let DATA_FORMAT = "json"
let NO_JSON_CALLBACK = "1"
let BOUNDING_BOX_HALF_WIDTH = 1.0
let BOUNDING_BOX_HALF_HEIGHT = 1.0
let LAT_MIN = -90.0
let LAT_MAX = 90.0
let LON_MIN = -180.0
let LON_MAX = 180.0

class PhotoAlbum: UIViewController, MKMapViewDelegate, UICollectionViewDelegate {
    var selectedPin: Pin!
    var photo: Photo?
    var photos = [Photo]()
    private let reuseIdentifier = "FlickrCell"
    private var searches = [FlickrSearchResults]()
    private let flickr = Flickr()
    
    @IBAction func buttonDone(sender: UIBarButtonItem) {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    @IBOutlet weak var mapView: MKMapView!
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    @IBAction func buttonNewCollection(sender: UIButton) {
        print("this should call a new search on flickr")
    }

    lazy var coreDataStack = CoreDataStack()

    override func viewDidLoad() {
        super.viewDidLoad()
        self.collectionView.delegate = self
        let pinLatitude = selectedPin.latitude as Double
        let pinLongitude = selectedPin.longitude as Double
        
        // load coordinate on map
        let initialLocation = CLLocation(latitude: pinLatitude, longitude: pinLongitude)
        let coordinate = CLLocationCoordinate2D(latitude: pinLatitude, longitude: pinLongitude)
        let myAnnotation = MKPointAnnotation()
        myAnnotation.coordinate = coordinate
        mapView.addAnnotation(myAnnotation)
        centerMapOnLocation(initialLocation)
        
        //function finds flickr photos from selected pin coordinates
        pinShouldReturn(selectedPin.latitude, lon: selectedPin.longitude)
        
        fetchStoredPhotos()
    }
    
    
    func fetchStoredPhotos() -> [Photo]{
        let fetchRequest = NSFetchRequest(entityName: "Photo")
        do {
            let results = try coreDataStack.managedObjectContext.executeFetchRequest(fetchRequest)
            print("PhotoResults-> \(results as! [Photo])")
            return results as! [Photo]
        } catch let error as NSError {
            print("Error in fetchAllPins(): \(error)")
        }
        return []
        
    }

    let regionRadius: CLLocationDistance = 1000
    func centerMapOnLocation(location: CLLocation) {
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate, regionRadius * 2.0, regionRadius * 2.0)
        mapView.setRegion(coordinateRegion, animated: true)
    }
}


extension PhotoAlbum : UITextFieldDelegate {

    //search for flickr photos using selected pin coordinates
    func pinShouldReturn(lat: NSNumber, lon: NSNumber) -> Bool {
        flickr.searchFlickrForLocationStoreResults(lat, lon: lon) {
            results, error in

            if error != nil {
                print("Error searching : \(error)")
            }
            
            if results != nil {
                //3
                self.searches.insert(results!, atIndex: 0)
            
                //4
                self.collectionView?.reloadData()
            }
        }
        return true
    }
}

//extension PhotoAlbum: PinPickerDelegate {
//    func didSelectPin(pin: Pin) {
//        photo?.location = pin
//        print("pin selected: \(photo?.location)")
//    }
//}